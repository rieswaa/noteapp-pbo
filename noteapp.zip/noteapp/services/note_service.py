from models.note import Note
import os

class NoteService:
    def __init__(self, file_path="data/notes.txt"):
        self.file_path = file_path

    def tambah_catatan(self, note):
        with open(self.file_path, "a") as file:
            file.write(f"{note.title}|{note.content}\n")

    def lihat_catatan(self):
        notes = []
        if not os.path.exists(self.file_path):
            return notes

        with open(self.file_path, "r") as file:
            for line in file:
                title, content = line.strip().split("|")
                notes.append(Note(title, content))
        return notes

    def hapus_semua_catatan(self):
        open(self.file_path, "w").close()
