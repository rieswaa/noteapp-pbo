from models.note import Note
from services.note_service import NoteService

def menu():
    print("\n=== Aplikasi Catatan Harian ===")
    print("1. Tambah Catatan")
    print("2. Lihat Catatan")
    print("3. Hapus Semua Catatan")
    print("0. Keluar")

note_service = NoteService()

while True:
    menu()
    pilih = input("Pilih menu: ")

    if pilih == "1":
        title = input("Judul: ")
        content = input("Isi: ")
        note = Note(title, content)
        note_service.tambah_catatan(note)
        print("✅ Catatan ditambahkan!")
    elif pilih == "2":
        notes = note_service.lihat_catatan()
        if notes:
            for i, n in enumerate(notes, 1):
                print(f"\nCatatan {i}:\n{n}")
        else:
            print("📭 Belum ada catatan.")
    elif pilih == "3":
        note_service.hapus_semua_catatan()
        print("🗑️ Semua catatan telah dihapus.")
    elif pilih == "0":
        break
    else:
        print("❌ Pilihan tidak valid.")
